#include<iostream>
#include"Stack.h"
using namespace std;
#pragma region Stack
template<typename T>
void Stack<T>::resize(int nSize)
{
	if (nSize == 0)
	{
		capacity = 1;
		nSize = 1;
	}
	if (nSize > 0)
	{
		T* temp = new T[nSize];
		for (int i = 0;i < top;i++)
			temp[i] = data[i];
		capacity = nSize;
		data = temp;
	}
}
template<typename T>
Stack<T>::Stack()
{
	capacity = 0;
	top = 0;
	data = nullptr;
}
template<typename T>
Stack<T>::Stack(const Stack<T>& obj) : Stack<T>()
{
	if (obj.data)
	{
		this->data = new T[obj.capacity];
		for (int i = 0;i < obj.top;i++)
			data[i] = obj.data[i];
		capacity = obj.capacity;
		top = obj.top;
	}
}
template<typename T>
Stack<T>& Stack<T>:: operator =(const Stack <T>& obj)
{
	if (this == &obj)
		return *this;
	if (obj.data)
	{
		this->data = new T[obj.capacity];
		for (int i = 0;i < obj.top;i++)
			data[i] = obj.data[i];
		capacity = obj.capacity;
		top = obj.top;
	}
	else this->~Stack();
	return *this;
}
template<typename T>
Stack<T>::~Stack()
{
	if (data)
	{
		delete[]data;
		capacity = 0;
		top = 0;
	}
}
template<typename T>
void Stack<T>::Push(T element)
{
	if (isFull())
		resize(2 * capacity);
	data[top] = element;
	top++;
}
template<typename T>
T Stack<T>::Pop()
{
	if (isEmpty())
	{
		//cout << "pop ";
		exit(0);
	}
		
	if (capacity / 4 == top)
		resize(capacity / 2);
	top--;
	return data[top];
}
template<typename T>
T Stack<T>::stackTop()const
{
	if (top == 0)
	{
		cout << "StackTop stop";
		exit(0);
	}
	return data[top - 1];
}
template<typename T>
bool Stack<T>::isFull()const
{
	if (top == capacity)
		return 1;
	return 0;
}
template<typename T>
bool Stack<T>::isEmpty()const
{
	if (top == 0)
		return 1;
	return 0;
}
template<typename T>
int	Stack<T>::getCapcity()
{
	return capacity;
}
template<typename T>
int	Stack<T>::getNumberOfElements()const
{
	return top;
}
#pragma endregion
