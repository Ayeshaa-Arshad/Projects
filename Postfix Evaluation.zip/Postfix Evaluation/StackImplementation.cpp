#include<iostream>
#include"Stack.cpp"
using namespace std;
template class Stack<float>;