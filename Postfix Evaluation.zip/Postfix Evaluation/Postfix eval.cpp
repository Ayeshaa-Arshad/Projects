#include<iostream>
#include<string>
#include"Stack.h"
#include<cmath>
#include<cstring>
using namespace std;
int isOperator(char n)
{
	switch (n)
	{
	case '+':
	{
		return 2;
		break;
	}
	case '-':
	{
		return 1;
		break;
	}
	case '*':
	{
		return 3;
		break;
	}
	case '/':
	{
		return 4;
		break;
	}
	case '^':
	{
		return 5;
		break;
	}
	}
	return 0;
}

float postfixEvaluation(string a)
{
	Stack<float>operands;
	int i = 0; string x;
	int length = a.length();
	while (i < length && a[i] != '\0')
	{
		if (!isOperator(a[i]))
		{
			if (a[i] == ' ')
				i++;
			while (i < length && a[i] != ' ')
			{
				x = x + a[i];
				i++;
			}
			operands.Push(stof(x));
		}
		else if (isOperator(a[i]) != 0)
		{
			if (operands.isEmpty())
			{
				cout << "Two operands required for operator!\n";
				exit(0);
			}
			float op2 = operands.Pop();
			if (operands.isEmpty())
			{
				cout << "Two operands required for operator!\n";
				exit(0);
			}
			float op1 = operands.Pop();
			if (isOperator(a[i]) == 1)
				operands.Push(op1 - op2);
			if (isOperator(a[i]) == 2)
				operands.Push(op1 + op2);
			if (isOperator(a[i]) == 3)
				operands.Push(op1 * op2);
			if (isOperator(a[i]) == 4)
			{
				if (op2 == 0)
				{
					cout << "Division By Zero Is Not Allowed!!\n";
					exit(0);
				}
				operands.Push(op1 / op2);
			}

			if (isOperator(a[i]) == 5)
				operands.Push(pow(op1, op2));
			i++;
		}
		i++;
		x = " ";
	}
	return operands.Pop();
}



	int main()
	{
		string expression;
		cout << "Write Postfix string separated by spaces" << endl;
		getline(cin, expression);
		cout << postfixEvaluation(expression);
	}
