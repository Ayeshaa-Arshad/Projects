#pragma once
template<typename T>
class Stack
{
	T* data;
	int capacity;
	int top;
	void resize(int nSize);
public:
	Stack();
	Stack(const Stack<T>& obj);
	Stack<T>& operator =(const Stack <T>& obj);
	~Stack();
	void Push(T element);
	T Pop();
	T stackTop()const;
	bool isFull()const;
	bool isEmpty()const;
	int getCapcity();
	int getNumberOfElements()const;
};